package org.cis1200.Sudoku;

public record PlayerInfo(String name, long time) {
}

