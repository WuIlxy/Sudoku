package org.cis1200.Sudoku;

public class RunSudoku implements Runnable {
    public void run() {
        new GenerateGame();
    }
}
